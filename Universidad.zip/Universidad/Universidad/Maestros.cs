﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using System.Net;

namespace Universidad
{
    public partial class Maestros : Form
    {
        public Maestros()
        {

            InitializeComponent();
        }

        private void Maestros_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            string apellidoPaterno = txtApellidoPaterno.Text;
            string apellidoMaterno = txtApellidoMaterno.Text;
            string matricula = txtMatricula.Text;
            DateTime fechaIngreso = dateTimePickerFechaIngreso.Value;
            string email = lblEmail.Text;
            string telefono = txtTelefono.Text;

            // Establecer la conexión con la base de datos
            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-29USEDN\\SQLEXPRESS;Integrated Security=True"))
            {
                connection.Open();

                // Preparar la consulta SQL o el procedimiento almacenado
                string query = "INSERT INTO Maestros (Nombre, ApellidoPaterno, ApellidoMaterno, Matricula, FechaIngreso, Email, Telefono) " +
                               "VALUES (@Nombre, @ApellidoPaterno, @ApellidoMaterno, @Matricula, @FechaIngreso, @Email, @Telefono)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Asignar los valores de los parámetros
                    command.Parameters.AddWithValue("@Nombre", nombre);
                    command.Parameters.AddWithValue("@ApellidoPaterno", apellidoPaterno);
                    command.Parameters.AddWithValue("@ApellidoMaterno", apellidoMaterno);
                    command.Parameters.AddWithValue("@Matricula", matricula);
                    command.Parameters.AddWithValue("@FechaIngreso", fechaIngreso);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Telefono", telefono);

                    // Ejecutar la consulta
                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Datos guardados correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
